          
           
           <li class="nav-item">
                <a class="nav-link collapsed" href="{{route('user')}}" >
                    <i class="fas fa-fw fa-cog"></i>
                    <span>DATA PENGGUNA</span>
                </a>
             
            </li>

            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link collapsed" href="{{route('candidate')}}" >
                    <i class="fas fa-fw fa-cog"></i>
                    <span>DATA CALON PENERIMA</span>
                </a>
             
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="{{route('criterias.index')}}" >
                    <i class="fas fa-fw fa-cog"></i>
                    <span>DATA KRITERIA</span>
                </a>
             
            </li>

            
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link collapsed" href="{{route('rangking.index')}}" >
                    <i class="fas fa-fw fa-cog"></i>
                    <span>PERANGKINGAN</span>
                </a>
             
            </li>

    


          

           
