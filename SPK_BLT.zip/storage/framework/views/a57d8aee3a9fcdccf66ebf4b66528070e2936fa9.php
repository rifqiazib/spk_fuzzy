
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('operator.candidate')); ?>" >
                    <i class="fas fa-fw fa-cog"></i>
                    <span>DATA CALON PENERIMA</span>
                </a>
             
            </li>


    


          

           
<?php /**PATH E:\SKRIPSI\SPK_BLT\resources\views/operator/sidebar.blade.php ENDPATH**/ ?>